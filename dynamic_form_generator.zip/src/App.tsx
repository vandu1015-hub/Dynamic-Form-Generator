
import React, { useState } from "react";
import FormGenerator from "./components/FormGenerator";

const App = () => {
  const [json, setJson] = useState({
    formTitle: "Dynamic Form",
    fields: [
      { id: "name", type: "text", label: "Name", required: true, placeholder: "Enter your name" }
    ],
  });

  return (
    <div className="flex h-screen">
      <div className="w-1/2 p-4 border-r">
        <textarea
          value={JSON.stringify(json, null, 2)}
          onChange={(e) => setJson(JSON.parse(e.target.value))}
          className="w-full h-full border p-2"
        />
      </div>
      <div className="w-1/2 p-4">
        <FormGenerator schema={json} />
      </div>
    </div>
  );
};

export default App;
