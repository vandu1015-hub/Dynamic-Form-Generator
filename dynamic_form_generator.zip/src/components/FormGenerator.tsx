
import React from "react";
import { useForm, Controller } from "react-hook-form";

const FormGenerator = ({ schema }) => {
  const { control, handleSubmit } = useForm();

  const onSubmit = (data) => {
    console.log("Form Submitted:", data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <h2>{schema.formTitle}</h2>
      {schema.fields.map((field) => (
        <div key={field.id} className="mb-4">
          <label className="block mb-1">{field.label}</label>
          <Controller
            name={field.id}
            control={control}
            defaultValue=""
            render={({ field }) =>
              field.type === "text" ? (
                <input {...field} className="border p-2 w-full" placeholder={field.placeholder} />
              ) : null
            }
          />
        </div>
      ))}
      <button type="submit" className="bg-blue-500 text-white p-2">
        Submit
      </button>
    </form>
  );
};

export default FormGenerator;
