
# Dynamic Form Generator

This project implements a dynamic form generator that renders forms from a JSON schema in real-time. 
It features a split-screen interface with a JSON editor and a preview of the generated form.

## Features
- Real-time JSON editing and validation.
- Dynamic form rendering with error states.
- Mobile-responsive design.
- Styled with Tailwind CSS.
- Tests using Jest and Playwright.

## Getting Started

### Prerequisites
- Node.js and npm installed.

### Setup
1. Clone the repository.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm start
   ```

### Example JSON Schema
```json
{
  "formTitle": "Project Requirements Survey",
  "formDescription": "Please fill out this survey about your project needs",
  "fields": [
    {
      "id": "name",
      "type": "text",
      "label": "Full Name",
      "required": true,
      "placeholder": "Enter your full name"
    },
    {
      "id": "email",
      "type": "email",
      "label": "Email Address",
      "required": true,
      "placeholder": "you@example.com",
      "validation": {
        "pattern": "^[^\s@]+@[^\s@]+\.[^\s@]+$",
        "message": "Please enter a valid email address"
      }
    }
  ]
}
```

## License
This project is licensed under the MIT License.
